// fixture extension entrypoint
